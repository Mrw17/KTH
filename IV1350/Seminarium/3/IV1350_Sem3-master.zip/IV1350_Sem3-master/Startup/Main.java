import view.*;
import controller.*;
import integration.RecipePrinter;
/**
 * Start up for the program
 * @author Daniel
 * @since 2019-06-02
 * @version 1.0
 */
public class Main {

	/**
	 * Main-method that runs the program
	 * Creates controller object and sends it to 
	 * View instance. 
	 * Runs small demonstration of the program 
	 * @param args
	 */
	public static void main(String[] args) {
		Controller controller = new Controller();
		View view = new View(controller); 
		view.showDemostration();
	}

}
