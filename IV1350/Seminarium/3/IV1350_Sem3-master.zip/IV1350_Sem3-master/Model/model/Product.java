package model;

/**
 * 
 * @author Daniel
 * @version 1.12
 * @since 2019-05-22
 */
public class Product {
	private int eanCode = 0;
	private String name = "";
	private double price = 0;
	private VATClass vatClass = VATClass.normal;
	private int amountSold = 1;
	private double discount = 0;

	/***
	 * Creates a standard product without and specific data
	 */
	public Product() {
	}
	
	
	/**
	 * Creates a product 
	 * @param eanCodeIn eancode of the product
	 */
	public Product(int eanCodeIn)
	{
		this.eanCode = eanCodeIn;
	}
	
	/**
	 * Creates a Product object
	 * @param eanCodeIn eancode of the product
	 * @param nameIn name of the product
	 * @param priceIn price of the product
	 */
	public Product(int eanCodeIn, String nameIn, double priceIn) {
		this.eanCode = eanCodeIn;
		this.name = nameIn;
		this.price = priceIn;
	}
	
	/**
	 * @param EANIn eancode of the product
	 * @param nameIn name of the product
	 * @param priceIn price of the product
	 * @param vatIn vatclass of the produt
	 */
	public Product(int eanCodeIn, String nameIn, double priceIn, VATClass vatIn) {
		this.eanCode = eanCodeIn;
		this.name = nameIn;
		this.price = priceIn;
		this.vatClass = vatIn;
	}
	
	/**
	 * Overrides toString 
	 * @return name of the product
	 */
	public String toString() {
		return this.name + " " + this.price;	
	}


	/**
	 * @return price
	 */
	public double getPrice() {
		return this.price;
	}

	/**
	 * Updates price with the given
	 * @price new price of the product
	 */
	public void setPrice(double price) { 
		this.price = price;
	}

	/**
	 * @return EANCode
	 */
	public int getEAN() {
		return this.eanCode;
	}

	/**
	 * Updates eancode with the given
	 * @param newEanCode ean code of the product
	 */
	public void setEAN(int newEanCode) {
		this.eanCode = newEanCode;
	}

	/**
	 * @return the name of the product
	 */
	public String getName() {
		return name;
	}

	
	/**
	 * Sets name with the given
	 * @param nameIn is the new name of the product
	 */
	public void setName(String newName) {
		this.name = newName;
	}
	
	/**
	 * @return vatClass as double (25% will be 1.25)
	 */
	public double getVatToMultipleToTotPrice(){
		return vatClass.CalcVatMultipleToTotPrice(this.vatClass);
	}

	/**
	 * 
	 * @return total VAT of the sale
	 */
	public double getToTVat() {
		return (this.price * this.getVatToMultipleToTotPrice()) - this.price;
	}

	/**
	 * @return customers VAT-class
	 */
	public VATClass getVatClass() {
		return this.vatClass;
	}
	
	/**
	 * Updates amountSold with one 
	 */
	public void addOneMoreProduct() {
		this.amountSold++;
	}
	
	/**
	 * 
	 * @return amountSold
	 */
	public int getAmountSold() {
		return this.amountSold;
	}
	
	/**
	 * 
	 * @return price * amount sold
	 */
	public double getPriceTimesAmount() {
		return (this.price * this.amountSold);
	}
	
	/**
	 * 
	 * @return discount
	 */
	public double getDiscount() {
		return discount;
	}

	/**
	 * Sets discount to the given
	 * @param newDiscount new discount amount
	 */
	public void setDiscount(double newDiscount) {
		this.discount = newDiscount;
	}

	/**
	 * Calculate total price with formula
	 * (amount of products - discount) * vatprocent
	 * @return total price with VAT
	 */
	public double getToTPriceIncVAT() {
		return (this.amountSold - this.discount) * this.vatClass.VatProcent();
	}
}
