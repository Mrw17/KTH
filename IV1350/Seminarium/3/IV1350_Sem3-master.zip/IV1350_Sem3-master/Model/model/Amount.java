package model;

/**
 * Class that is resposible for all type of amounts
 * eg. totAmount, totAmountWihtDiscount, vat etc
 * @author Daniel
 * @version 1.1
 * @since 2019-05-22
 *
 */
public class Amount {

	/**
	 * Default constructor
	 */
	public Amount() {}
	
	/**
	 * Calculate total price without discount
	 * @param shoppingBasket2 
	 * @return total price without discount
	 */
	public double getToTPriceWithoutSaleDiscount(ProductList productList) {
		double sum = 0;
		
		for(int i = 0; i < productList.numberOfProductsInProductList(); i++) {
			sum += productList.getProduct(i).getPriceTimesAmount();
		}		
		return sum;
	}

	/**
	 * Calculate total price with Sale Discounts 
	 * Ex, 3 cheese  for 2 etc
	 * @param productList list with all products
	 * @return total discount sum
	 */
	public double getToTPriceWithSaleDiscount(ProductList productList) {
		double sum = 0;
		CurrentDiscounts currentDiscounts = new CurrentDiscounts();
		productList = currentDiscounts.getDiscountAmount(productList);
	
		for(int i = 0; i < productList.numberOfProductsInProductList(); i++)
			sum += (productList.getProduct(i).getPriceTimesAmount() - productList.getProduct(i).getDiscount());
		return sum;
	}
	
	/**
	 * calculate change 
	 * @param currCustomer 
	 * @param productList 
	 * @return change
	 */
	public String getChangeStr(ProductList productList, Customer currCustomer) {		
		String output = "";
		double change = calcChange(productList, currCustomer);
		
		if(change > 0)
			output = ("You haven't payed enough, still missing:  ");
		else if(change <= 0)
			output = ("You have  payed enough, change is:  ");
		
		output += Math.abs(calcChange(productList, currCustomer));

		return output;
	}
	
	/**
	 * @param productList 
	 * @return customers change
	 */
	public double calcChange(ProductList productList, Customer customer) {
		double totPrice = this.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT(productList, customer.getDiscountClass());
		double amountPayedByCustomer = customer.GetAmountPayed();
		return totPrice - amountPayedByCustomer;
	}
	
	/**
	 * Calculate difference between price before discount and after
	 * @return how much discount a customer got
	 */
	public double getToTDiscount(ProductList shoppingBasket) {
		double totPriceBeforeDiscount = this.getToTPriceWithoutSaleDiscount(shoppingBasket);
		double totPriceDiscountAfterDiscount = this.getToTPriceWithoutSaleDiscount(shoppingBasket);
		
		return (totPriceBeforeDiscount - totPriceDiscountAfterDiscount);
	}

	/**
	 * Calculate total price, with sale discount, member discount and VAT
	 * @param productList with all products
	 * @param customersDiscountClass 
	 * @return total price 
	 */
	public double getToTPriceWithSaleDiscountAndMemberDiscountAndVAT(ProductList productList, DiscountClass customersDiscountClass) {
		double totVat = this.getToTVAT(productList);
		
		double totPriceWithDiscount = this.getToTPriceWithSaleDiscountAndMemberDiscount(productList, customersDiscountClass);
		
		return (totVat + totPriceWithDiscount);
		
	}
	
	/**
	 * 
	 * @param productList with all the products
	 * @return total amount of VAT of all products
	 */
	public double getToTVAT(ProductList productList) {
		double sum = 0;
		
		for(int i = 0; i < productList.numberOfProductsInProductList(); i++)
			sum += productList.getProduct(i).getToTVat();
		
		return sum; 
	}
	
	/**
	 * Adds discount on a sale that depends on the customers MembersGroup
	 * @param productList contains all products 
	 * @param customersDiscountCLass contains customers discount class with right discount
	 * @return total discount with added members discount
	 */
	public double getToTPriceWithSaleDiscountAndMemberDiscount(ProductList productList, DiscountClass customersDiscountClass) {
		double discountPercentage = customersDiscountClass.getDiscountClass();	
		double discountAmount = this.getToTPriceWithSaleDiscount(productList);
		return (discountAmount * discountPercentage);
	} 
}
