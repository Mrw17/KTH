package model;

/**
 * enum that contains information about
 * all diffrent VAT groups
 * @author Danie
 * @version 1.1
 * @since 2019-05-22
 *
 */
public enum VATClass {
	alcohol(20.0),
	normal(25.0),
	lottery(15.0),
	tobaco(30.0),
	vegetables(10.0),
	;
	
	private double vatAmount;
	private String vatName;
	
	VATClass(double Vat){
		this.vatAmount = Vat;
	}
	
	/**
	 * 
	 * @return vat amount
	 */
	public double VatProcent() {
		return vatAmount;
	}
	
	/**
	 * Takes a vatClass (ex. 25%) and makes it to an double (ex. 1.25)
	 * @param vatClass
	 * @return 
	 */
	public double CalcVatMultipleToTotPrice(VATClass vatClass) {
		return ( (vatClass.VatProcent() / 100) + 1 );
	}
	
	/**
	 * Takes a VAT class string and return its value 
	 * @param vatName name of a VAT group
	 * @return vatNames value as double
	 */
	public double getVATByString(String vatName){
        for(VATClass vatClass : VATClass.values()){
            if(vatName == vatClass.vatName) return vatClass.vatAmount;
        }
        return (Double) null;
    }
	
}
