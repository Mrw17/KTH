package model;
/**
 * Class that holds information about the Store
 * @author Daniel
 * @version 1.1
 * @since 2019-05-22
 */
public class Store {
	
	String name = "";
	Address address = new Address();
	
	/**
	 * Default constructor
	 */
	public Store() {}
	
	/**
	 * Creates a new store with the given name and address
	 * @param nameIn the name of the store
	 * @param addressIn the address of the store
	 */
	public Store(String nameIn, Address address) {
		this.name = nameIn;
		this.address = address;
	}
	
	
	/**
	 * Sets the name of the store to the given name
	 * @param nameIn the name of the store
	 */
	public void setName(String nameIn) {
		this.name = nameIn;
	}
	
	/**
	 * Returns the name of the store
	 * @return the name of the store
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Sets the address of the store to the given address
	 * @param newAddress the address of the store
	 */
	public void setAddress(Address newAddress) {
		this.address = newAddress;
	}

	/**
	 * 
	 * @return address of the store
	 */
	public String getAddress() {
		return this.address.toString();
	}
	
	/**
	 * Overrides toString and prints out
	 * name and address of the Store Object
	 */
	@Override
	public String toString() {
		return this.name + " " + this.address;
	}

	/**
	 * Updates street name with the given
	 * @param newStreetname new street name
	 */
	public void setAddressStreetname(String newStreetname) {
		this.address.setStreetName(newStreetname);
	}

	/**
	 * Updates house number with the given
	 * @param newHouseNumber new house number
	 */
	public void setAddressHouseNumber(String newHouseNumber) {
		this.address.setHouseNumber(newHouseNumber);
		
	}

	/**
	 * Updates zip code with the given
	 * @param newZipCode new zip code
	 */
	public void setAddressZipCode(int newZipCode) {
		this.address.setZipCode(newZipCode);
		
	}

	/**
	 * Updates city with the given
	 * @param newCity new city 
	 */
	public void setAddressCity(String newCity) {
		this.address.setCity(newCity);
	}
}
