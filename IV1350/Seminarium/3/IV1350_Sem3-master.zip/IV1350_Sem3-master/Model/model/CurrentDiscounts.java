package model;
import java.util.ArrayList;

import integration.ExternalInventory;

/** Class that responsible for applying discount to a sale
 * @author Daniel
 * @version 1.1
 * @since 2019-05-22
 */
public class CurrentDiscounts {
	
	/**
	 * Responsible for applying discount to a sale
	 * @param currSale current sale
	 * @return Sale object with updated total price
	 */
	public ProductList getDiscountAmount(ProductList productList)
	{		
		clearDiscounts(productList); 
		
		checksFor3CheesesDiscount(productList); 
		halfPriceOnProduct(productList);		
		
		return productList;
	}
	
	private void clearDiscounts(ProductList productList) {
		
		for(int i = 0; i < productList.numberOfProductsInProductList(); i++) {
			productList.getProduct(i).setDiscount(0);
		}
		
	}

	/**
	 * Checks if a Sale is eligible for a 
	 * buy 3 cheeses pay 2 discount
	 * @param saleToCheckForDiscount
	 * @return Sale object with updated total price
	 */
	private void checksFor3CheesesDiscount(ProductList productList) {
		double priceOfOneCheese = 0;
		double discount = 0;
		for(int i = 0; i < productList.numberOfProductsInProductList(); i++) {
			if(productList.getProduct(i).getName().equals("cheese")) {
			priceOfOneCheese = productList.getProduct(i).getPrice();
				if(productList.getProduct(i).getAmountSold() >= 3) {
					priceOfOneCheese = productList.getProduct(i).getPrice();
					int numOfDiscounts = (int) (productList.getProduct(i).getAmountSold() % 3);
					discount = productList.getProduct(i).getDiscount() + (priceOfOneCheese * numOfDiscounts);
					productList.getProduct(i).setDiscount(discount);
				}
			}
		}
	}
	
	
	/**
	 * Reduces the price by /2 on a specific product
	 * @param saleToCheckForDiscount Sale object to check
	 * @param eanCode eancode of the product, whose price has been reduced by /2
	 * @return
	 */
	private void halfPriceOnProduct(ProductList productList) {
		
		int discountDivider = 2;
		
		for(int i = 0; i < productList.numberOfProductsInProductList(); i++) {
			
			int eanCodeToCheckForDiscount = productList.getProduct(i).getEAN();
			
			if(checkIfProductIsInHalfPriceList(eanCodeToCheckForDiscount) == true){
				
				Product productThatGetsDiscount = productList.getProductFromEanCode(eanCodeToCheckForDiscount);
				
				double numberOfProducts = productThatGetsDiscount.getAmountSold();
				
				double priceOfOneProduct = productThatGetsDiscount.getPrice();
				
				double totDiscount = ((priceOfOneProduct * numberOfProducts)/discountDivider);
				
				productThatGetsDiscount.setDiscount(totDiscount);
				
				productList.updateProductWithSpecificEanCode(productThatGetsDiscount);
			}
		}
	}
	
	/**
	 * Contains a integer list with eancodes that is eligble to half price discount
	 * @return Integer list with all eancodes that is eligble to half price discount
	 */
	private ArrayList<Integer> listOffAllProductThatIsHalfPrice() {
	      ArrayList<Integer> halfPriceProducts = new ArrayList<Integer>();  
	      ExternalInventory inventory = new ExternalInventory();
	      
	      inventory.eligibleProductToSale(1002);
	      halfPriceProducts.add(1002);
	      
	      return  halfPriceProducts;
	}
	
	/**
	 * Checks if a certain eancode is eligbile to half price discount
	 * @param eanCodeToCheck eancode to be checked
	 * @return true if eancode is eligble to half price discount
	 */
	private boolean checkIfProductIsInHalfPriceList(int eanCodeToCheck) {
		boolean check = false;	
	    ArrayList<Integer> halfPriceProducts = listOffAllProductThatIsHalfPrice();
	    
	    for(Integer eanCodeInList : halfPriceProducts){
	    	if (eanCodeInList == eanCodeToCheck )
		    	check = true;
	    }

		return check;
	}

}