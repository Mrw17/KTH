package model;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestAddProductTest {

	Sale newSale = new Sale();

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		newSale = new Sale();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	
	@Test
	void testAddProductWithEanInInventory() {
		
		int eanCode = 1000;
		newSale.addProduct(eanCode);
		assertTrue(eanCode == newSale.getProductFromEanCode(eanCode).getEAN());
		assertTrue(newSale.getProductFromEanCode(eanCode).getName().equals("cheese"));
		assertTrue(newSale.getProductFromEanCode(eanCode).getPrice() == 20);
	}
	
	@Test
	void testAddProductWithEanNotInInventory() {
		int eanCode = 99999;		
		boolean check = false;
			
		newSale.addProduct(eanCode);
		if(newSale.getProductFromEanCode(eanCode) == null)
			check = true;
		
		assertTrue(check);
	}
	
	@Test void testAddMultipleProductsWithSameEan() {
		int eanCode = 1000;
		double productsToAdd = 3;
		
		for(int i = 0; i < productsToAdd; i++ ) {
			newSale.addProduct(eanCode);
		}
		
		assertTrue(eanCode == newSale.getProductList().getProduct(0).getEAN());
		assertTrue(newSale.getProductFromEanCode(eanCode).getAmountSold() == productsToAdd);		
	}
	
	/**
	 * Tries to add two products with diffrent Eancodes
	 * and comperes the eancodes on product object with the given 
	 */
	@Test void testAddMultipleProductsWithDiffrentEan() {
		int eanCodeCheese = 1000;
		
		int eanCodeScratch = 1001;
		
		newSale.addProduct(eanCodeCheese);
		newSale.addProduct(eanCodeScratch);
			
		assertTrue(eanCodeCheese == newSale.getProductList().getProduct(0).getEAN());
		assertTrue(newSale.getProductFromEanCode(eanCodeCheese).getEAN() == eanCodeCheese);
		
		assertTrue(eanCodeScratch == newSale.getProductList().getProduct(1).getEAN());
		assertTrue(newSale.getProductFromEanCode(eanCodeScratch).getEAN() == eanCodeScratch);
	}

	
	/**
	 * Tries to add multiple products with both same and different eancodes
	 * and comperes with checks that both right price and and amountSold was added
	 */
	@Test void testAddMultipleProductsWithBothDiffrentAndSameEan() {
		int eanCodeCheese = 1000;
		int priceCheese = 20;
		
		int eanCodeScratch = 1001;
		int priceOfScratch = 25;
		
		double productsToAdd = 3;
		
		for(int i = 0; i < productsToAdd; i++ ) {
			newSale.addProduct(eanCodeCheese);
			newSale.addProduct(eanCodeScratch);
		}
				
		assertTrue(eanCodeCheese == newSale.getProductList().getProduct(0).getEAN());
		assertTrue(newSale.getProductFromEanCode(eanCodeCheese).getAmountSold() == productsToAdd);	
		assertTrue(newSale.getProductFromEanCode(eanCodeCheese).getPrice() == priceCheese);
		
		assertTrue(eanCodeScratch == newSale.getProductList().getProduct(1).getEAN());
		assertTrue(newSale.getProductFromEanCode(eanCodeScratch).getAmountSold() == productsToAdd);
		assertTrue(newSale.getProductFromEanCode(eanCodeScratch).getPrice() == priceOfScratch);
	}
}
