package model;

/**
 * 
 * @author Daniel
 * @since 2019-06-02
 * @version 1.0
 */
public class SaleDTO {

	Customer customer = new Customer();
	double totPriceWithoutDiscount = 0;
	double totPriceWithdiscount = 0;
	double totDiscount = 0;
	double totVat= 0;
	double totChange = 0;
	ProductList productList = new ProductList();
	String storeName = "";
	String storeAddress = "";
	String dateOfSale = "";
	double amountPayedByCustomer = 0;
	double totPriceWithDiscountAndVat = 0;
	
	/**
	 * Saves data from Store-object and Sale-object
	 * @param store 
	 * @param newSale
	 */
	public SaleDTO(Store store, Sale newSale) {
		this.customer = newSale.getCustomer();
		this.totPriceWithoutDiscount = newSale.getToTPriceWithoutDiscount();
		this.totPriceWithdiscount = newSale.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT();
		this.totDiscount = newSale.getToTPriceWithoutDiscount() - newSale.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT();
		this.totVat = newSale.getTotVat();
		this.totChange = newSale.getTotChange();
		this.productList = newSale.getProductList();
		this.storeAddress = store.getAddress();
		this.storeName = store.getName();
		this.dateOfSale = newSale.getApprovedDate();
		this.amountPayedByCustomer = newSale.getAmountPayedByCustomer();
		this.totPriceWithDiscountAndVat = newSale.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT();
	}
	
	/**
	 * Defualt constructor
	 */
	public SaleDTO() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @return current customer
	 */
	public Customer getCustomer() {
		return customer;
	}

	/**
	 * 
	 * @return total price without discount
	 */
	public double getTotPriceWithoutDiscount() {
		return totPriceWithoutDiscount;
	}


	/**
	 * 
	 * @return total price with discount
	 */
	public double getTotPriceWithdiscount() {
		return totPriceWithdiscount;
	}

	/**
	 * 
	 * @return total amount of discount
	 */
	public double getTotDiscount() {
		return totDiscount;
	}

	/**
	 * 
	 * @return total amount of VAT
	 */
	public double getTotVat() {
		return totVat;
	}

	/**
	 * 
	 * @return list with all products
	 */
	public ProductList getProductList() {
		return this.productList;
	}
	
	/**
	 * 
	 * @return name of the store
	 */
	public String getStoreName() {
		return storeName;
	}

	/**
	 * 
	 * @return address of the store
	 */
	public String getStoreAddress() {
		return storeAddress;
	}

	/**
	 * 
	 * @return total change
	 */
	public double getTotChange() {
		return totChange;
	}

	/**
	 * 
	 * @return date of the sale
	 */
	public String dateOfSale() {
		return this.dateOfSale;
	}

	/**
	 * 
	 * @return amount payed by customer
	 */
	public double getAmountPayedByCustomer() {
		return this.amountPayedByCustomer;
	}

	/**
	 * 
	 * @return total price without discount and VAT
	 */
	public double getTotPriceWithoutDiscountAndVAT() {
		return this.totPriceWithDiscountAndVat;
	}
	
}
