package model;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Class that handels both customer and cashiers 
 * approved sale status 
 * @author Daniel
 * @version 1.1
 * @since 2019-05-15
 */

public class ApprovedSale {
	private boolean customerApproved = false;
	private boolean cashierApproved = false;
	private String approvedTime = null;
	
	/**
	 * 
	 * @return customers approved status on current sale
	 */
	public boolean getCustomerApproved() {
		return customerApproved;
	}
	
	/**
	 * 
	 * @param customerApproved Customers  new approved status on current sale
	 */
	public void setCustomerApproved(boolean customerApproved) {
		this.customerApproved = customerApproved;
		this.checkIfBothApproved();
	}
	
	/**
	 * 
	 * @return cashiers approved status on current sale
	 */
	public boolean getCashierApproved() {
		return cashierApproved;
	}
	
	/**
	 * 
	 * @param cashierApproved New approved status on current sale
	 */
	public void setCashierApproved(boolean cashierApproved) {
		this.cashierApproved = cashierApproved;
		this.checkIfBothApproved();
	}
	
	/**
	 * Checks if both cashier and customer approved sale
	 * If both has approved, it saves the time.
	 */
	private void checkIfBothApproved() {
		if(this.cashierApproved && this.customerApproved)
			approvedTime();
	}
	
	/**
	 * Saves the time when both cashier and customer has approved sale
	 */
	private void approvedTime() {
		Date date = new Date();
		long time = date.getTime();
		Timestamp timestamp = new Timestamp(time);
		this.approvedTime = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(timestamp);
	}
	
	/**
	 * 
	 * @return approved time for sale 
	 */
	public String getApprovedTime() {
		return approvedTime;
	}

}
