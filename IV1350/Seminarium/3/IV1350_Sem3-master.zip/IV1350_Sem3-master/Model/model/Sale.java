package model;

import integration.*;

/**
 * Class that holds on information about a sale 
 * @author Daniel
 * @version 1.3
 * @since 2019-06-01
 *
 */
public class Sale {
	
	/**
	 * "shopping basket" that holds all the products
	 */
	private ProductList productList = new ProductList();
	private Customer currCustomer = new Customer();
	private ApprovedSale approvedSale = new ApprovedSale();
	private Amount amount = new Amount();

	
	/**
	 * Creates a product-object and check if its already
	 * exists in productList, if it does it increase soldAmount with one
	 * else it puts a new product in productList
	 * @param eanCodeIn eancode of the product
	 */
	public void addProduct(int eanCodeIn) {
		ExternalInventory extInventory = new integration.ExternalInventory();
		if(extInventory.eligibleProductToSale(eanCodeIn) == true) {
			Product newProduct = extInventory.getProductFromInventory(eanCodeIn);
			productList.addProduct(newProduct);
		}
	}
	
	/**
	 * Calculate total price without discount
	 * @return total price without discount
	 */
	public double getToTPriceWithoutDiscount() {
		return this.amount.getToTPriceWithoutSaleDiscount(this.productList);
	}
	
	/**
	 *
	 * @return total price with sale discount
	 */
	public double getToTPriceWithSaleDiscount() {
		return this.amount.getToTPriceWithSaleDiscount(this.productList);
	}

	/**
	 * Gets a product from the productList based on a products ean.
	 * @param eanCodeSearchingFor eancode to  search for.
	 * @return product object with eanCodeSearchingFor or null if it doesnt' exists in shopping basket.
	 */
	public Product getProductFromEanCode(int eanCodeSearchingFor){
		return this.productList.getProductFromEanCode(eanCodeSearchingFor);
	}
	

	/**
	 * Returns the number of products in the shopping basket
	 * @return size of productList
	 */
	public int numOfProducts()
	{
		return productList.numberOfProductsInProductList();
	}
	
	/**
	 * Adds a customer to the current sale
	 * @param newCustomer
	 */
	public void setCustomer(Customer newCustomer) {
		this.currCustomer = newCustomer;
	}
	
	/**
	 * Gets the current customer 
	 * @return current customer
	 */
	public Customer getCustomer() {
		return this.currCustomer;
	}
	
	/**
	 * calculate change 
	 * @return change
	 */
	public String getChange() {		
		return this.amount.getChangeStr(this.productList, this.currCustomer);
	}
	

	/**
	 * Sets approved sale status to the given
	 * @param status 
	 */
	public void setCashierApproved(boolean status) {
		approvedSale.setCashierApproved(status);
	}
	
	/**
	 * Sets approved customer status to the given
	 * @param status
	 */
	public void setCustomerApproved(boolean status) {
		approvedSale.setCustomerApproved(status);
	}

	/**
	 * Calculate difference between price before discount and after
	 * @return how much discount a customer got
	 */
	public double getTotDiscount() {
		return this.amount.getToTDiscount(this.productList);
	}
	
	/**
	 * 
	 * @return list with productList
	 */
	public ProductList getProductList(){
		return this.productList;
	}
	
	/**
	 * 
	 * @return list with productList
	 */
	public void setShoppingBasket(ProductList newProductList){
		this.productList = newProductList;
	}
	
	/**
	 * 
	 * @return string with approvedDate of the sale 
	 */
	public String getApprovedDate() {
		return approvedSale.getApprovedTime().toString();
	}

	/**
	 * 
	 * @return total price with sale Discount, member discount and VAT 
	 */
	public double getToTPriceWithSaleDiscountAndMemberDiscountAndVAT() {
		return this.amount.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT(this.productList, this.currCustomer.getDiscountClass());
	}

	/**
	 * 
	 * @return total price with salediscount and member discount
	 */
	public double getToTPriceWithSaleDiscountAndMemberDiscount() {
		return this.amount.getToTPriceWithSaleDiscountAndMemberDiscount(this.productList, this.currCustomer.getDiscountClass());
	}
	
	/**
	 * 
	 * @return total amount of VAT
	 */
	public double getTotVat() {
		return this.amount.getToTVAT(this.productList);
	}

	/**
	 * 
	 * @return total amount of change
	 */
	public double getTotChange() {
		return this.amount.calcChange(this.productList, this.currCustomer);
	}
	
	/**
	 * 
	 * @return amount that customer has payed
	 */
	public double getAmountPayedByCustomer() {
		return this.currCustomer.GetAmountPayed();
	}
}
