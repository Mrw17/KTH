package view;
import controller.*;

/**
 * Placeholder for view
 * @author Daniel
 * @version 1.0
 * @since 2019-05-16
 *
 */
public class View {
	
	Controller controller = new Controller();
	
	/**
	 * Default constructor
	 */
	public View() {}
	
	/**
	 * Constructor that takes a controller object
	 * @param controller
	 */
	public View(Controller controller) {
		this.controller = controller;
	}
	
	/**
	 * Runs a simple demonstration of the program
	 * with hard coded inputs
	 */
	public void showDemostration() {
		ViewDemo viewDemo = new ViewDemo(this.controller);
		viewDemo.showDemostration();
	}
	
}
