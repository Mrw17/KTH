package view;
import controller.*;

/**
 * Simple demonstration of the program
 * @author Daniel
 * @version 1.1
 * @since 2019-05-22
 *
 */
public class ViewDemo {
	
	Controller controller = new Controller();
	
	/**
	 * Constructor that takes a controller as argument
	 * @param controller new controller
	 */
	public ViewDemo(Controller controller) {
		this.controller = controller;
	}
	

	/**
	 * Runs a simple demonstration of the program
	 */
	public void showDemostration() {
		this.controller.setStoreAddressStreetname("Coolstreet");
		this.controller.setStoreAddressHouseNumber("123");
		this.controller.setStoreAddressZipCode(12345);
		this.controller.setStoreAddressCity("cooltown");
		
		this.controller.setStoreName("Very Cool shop");
		demostrationPrintStore();
		
		System.out.println("Current inventory (product, quantity)");
		System.out.println(controller.getInventory().toString());
			
		demostrationShowCashRegisterBalance();
		
		System.out.println("\n\n\n***Cashier starts a new sale***");
		controller.startNewSale();	
			 
			
		System.out.println("***Cashier scanning product(cheese)***");
		demostrationScanProduct(1000);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
		System.out.println("***Cashier scanning product(cheese)***");
		demostrationScanProduct(1000);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
		System.out.println("***Cashier scanning product(cheese)***");
		demostrationScanProduct(1000);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
		System.out.println("***Cashier scanning product(cheese)***");
		demostrationScanProduct(1000);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
			
		System.out.println("***Cashier scanning product(scratch)***");
		demostrationScanProduct(1001);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
			
			
		System.out.println("***Cashier scanning product(beer)***");
		demostrationScanProduct(1002);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
		System.out.println("***Cashier scanning product(beer)***");
		demostrationScanProduct(1002);
		demostrationShowToTPriceWithoutDiscountOrVAT();
					
		System.out.println("***Cashier scanning product(cigarette)***");
		controller.addProduct(1003);
		demostrationShowToTPriceWithoutDiscountOrVAT();
		
		System.out.println("***Cashier scanning product with eancode that doesnt exists in inventory***");
		demostrationScanProduct(1005);		
		demostrationShowToTPriceWithoutDiscountOrVAT();
		System.out.println("***No more products to scan***\n\n");	
		
		
		System.out.print("Show total price with discount: ");
		System.out.println(controller.getToTPriceWithDiscounts());
		
		System.out.print("Show total price with discount + VAT: ");
		System.out.println(controller.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT());
			
		System.out.println("***Customer  approves***");
		controller.setCustomerApproved(true);
				
		System.out.println("***Cashier approves***");
		controller.setCashierApprovedSale(true);
			
		demostrationCustomerPays(100);
		demostrationPrintChange();
		
	
		demostrationCustomerPays(100);
		demostrationPrintChange();		
			
		controller.createRecipe();
		System.out.println(controller.getRecipeOutput());
							
		controller.sendToExternalAccounting();
		controller.sendToExternalInventory();
			
		System.out.println("\n\nCurrent inventory (product, quantity)");
		System.out.println(controller.getInventory().toString());
	}
	
	/**
	 * Prints Change
	 */
	private void demostrationPrintChange() {
		System.out.println(controller.getChange());
	}
	
	/**
	 * Prints out how much customer pays
	 * @param amount
	 */
	private void demostrationCustomerPays(double amount) {
		System.out.println("Customer pays " + amount);
		controller.customerPays(amount);
	}
	
	/**
	 * Prints out cashregister balance
	 */
	private void demostrationShowCashRegisterBalance() {
		System.out.print("Current cashregister balance: ");
		System.out.println(controller.getCashRegisterBalance());
	}
	
	/**
	 * Add a product to the sale 
	 * @param ean
	 */
	private void demostrationScanProduct(int ean) {
		controller.addProduct(ean);
	}
	
	/**
	 * Prints out total price
	 */
	private void demostrationShowToTPriceWithoutDiscountOrVAT() {
		System.out.println("Show total price " + controller.getToTPriceWithoutDiscountOrVAT());
	}
	
	/**
	 * Prints out store information
	 */
	private void demostrationPrintStore() {
		System.out.println(this.controller.getStore().getName() + " " + this.controller.getStore().getAddress() + "\n\n");
	}
}
