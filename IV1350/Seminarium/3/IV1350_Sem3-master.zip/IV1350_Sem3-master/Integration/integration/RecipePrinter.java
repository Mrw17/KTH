package integration;

/**
 * Class that represents external system "RecipePrinter"
 * @author Daniel
 * @version 1.1
 * @since 2019-05-22
 *
 */
public class RecipePrinter {
	
	RecipePrinterDTO recipePrinterDTO = new RecipePrinterDTO();
	
	/**
	 * Create instance of RecipePrinter that gets all data from arguments
	 * @param recipePrinter contains all data about recipe
	 */
	public RecipePrinter(RecipePrinterDTO recipePrinter) {
		this.recipePrinterDTO = recipePrinter;
		
	}
	
	/**
	 * Default constructor
	 */
	public RecipePrinter() {}
	
	/**
	 * Prints out a example recipe
	 * @return a print of an example recipe 
	 */
	public String printRecipe() {
		String output = "\n*****Recipe*****\n";
		output += "Date: " + this.recipePrinterDTO.getDateOfSale();
		output += "\n" + this.recipePrinterDTO.getstoreName() + " " + this.recipePrinterDTO.getstoreAddress() +"\n"; 
					
		output += this.recipePrinterDTO.getAllProducts();
			
		output += "\nTotal price: " + this.recipePrinterDTO.getToTPrice();
		output += "\nTotal Discount " + this.recipePrinterDTO.getToTDiscount();
		output += "\nTotal VAT: " + this.recipePrinterDTO.getToTVat();
		output += "\n\nPaid: " + this.recipePrinterDTO.getAmountPayedByCustomer();
		output += "\nChange: " + this.recipePrinterDTO.getChange();
		
		output += "\n*****Recipe*****\n";
		return output;		
	}
}
