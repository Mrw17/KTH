package integration;
import java.text.DecimalFormat;
import model.ProductList;
import model.Recipe;

/**
 * 
 * @author Daniel
 * @version 1.01
 * @since 2019-05-22
 */
public class RecipePrinterDTO {
	private String storeName = "";
	private String storeAddress = "";
	private String dateOfSale = "";
	private double totPrice = 0;
	private double toTDiscount = 0;
	private double totVat = 0;
	private double amountPayedByCustomer = 0;
	private double change = 0;
	private ProductList productList = new ProductList();

	/**
	 * Default constructor 
	 */
	public RecipePrinterDTO() {}
	
	/**
	 * Construct that take a newRecipe object and 
	 * saves the data that needs to be sent to RecipePrinter class 
	 * @param newRecipe recipe to be printed
	 */
	public RecipePrinterDTO(Recipe newRecipe) {
		this.storeName = newRecipe.getStoreName();
		this.storeAddress = newRecipe.getStoreAddress().toString();
		this.dateOfSale = newRecipe.getdateOfSale();
		this.toTDiscount = newRecipe.getTotDiscount();
		this.totVat = newRecipe.getTotVat();
		this.change = newRecipe.getTotChange();
		this.totPrice = newRecipe.getTotPriceWithDiscountsAndVAT();
		this.amountPayedByCustomer = newRecipe.getAmountPayedByCustomer();	
		this.productList = newRecipe.getProductList();
	}
	
	/**
	 * 
	 * @return store name
	 */
	public String getstoreName() {
		return this.storeName;
	}
	
	/**
	 * 
	 * @return store address
	 */
	public String getstoreAddress() {
		return this.storeAddress;
	}
	
	/**
	 * 
	 * @return date of the sale
	 */
	public String getDateOfSale() {
		return this.dateOfSale;		
	}
	
	/**
	 * 
	 * @return total price of the sale
	 */
	public double getToTPrice() {
		return this.removeDecimals(this.totPrice);
	}
	
	public double getToTDiscount() {
		return this.removeDecimals(toTDiscount);
	}

	/**
	 * 
	 * @return total VAT of the sale
	 */
	public double getToTVat() {
		return this.removeDecimals(this.totVat);
	}
	
	/**
	 * 
	 * @return how much customer has payed
	 */
	public double getAmountPayedByCustomer() {
		return this.removeDecimals(this.amountPayedByCustomer);
	}
	
	/**
	 * 
	 * @return how much change customer shall receive 
	 */
	public double getChange() {
		return this.removeDecimals(this.change);
	}
	
	
	/**
	 * Round a double number to 2 decimals, with help of DecimalFormat class
	 * (needs to use string.replaceAll to transform , -> .) 
	 * @param doubleToRound double number that should rounded to 2 decimals
	 * @return double number with only two decimals
	 */
	private double removeDecimals(double doubleToRound) {
		double output = 0;
		String strDoubleToTrim = Double.toString(doubleToRound);
		DecimalFormat decimalFormat = new DecimalFormat();
		
		strDoubleToTrim = decimalFormat.format(doubleToRound);
		strDoubleToTrim = strDoubleToTrim.replaceAll("," , ".");
		
		output = Double.parseDouble(strDoubleToTrim);
		return output;
	}
	
	
	/**
	 * 
	 * @return productList list with all product objects
	 */
	public String getAllProducts(){
		String output = "";
		for(int i = 0; i < this.productList.numberOfProductsInProductList(); i++)
			output += this.productList.getProduct(i).toString() + " x " + productList.getProduct(i).getAmountSold() + "\n";
		
		return output;
	}
}
