package model;

/**
 * Class that represents a recipe
 * @author Daniel
 * @version 1.1
 * @since 2019-05-22
 *
 */
public class Recipe {
	double totDiscount = 0;
	double totVat = 0;
	double totChange = 0;
	ProductList productList = new ProductList();
	String storeName = "";
	String storeAddress = "";
	String dateOfSale = "";
	double amountPayedByCustomer = 0;
	double totPrice = 0;
	
	public Recipe() {}
	
	/**
	 * Constructor that takes instances of both Store and Sale
	 * @param store Store object that contains data about the store that the sale was made in
	 * @param sale Sale object that contains data about a sale
	 */
	public Recipe(SaleDTO saleDTO) {
		this.totDiscount = saleDTO.getTotDiscount();
		this.totVat = saleDTO.getTotVat();
		this.totChange = saleDTO.getTotChange();
		this.productList = saleDTO.getProductList();
		this.storeAddress = saleDTO.getStoreAddress();
		this.storeName = saleDTO.getStoreName();
		this.dateOfSale = saleDTO.dateOfSale();
		this.amountPayedByCustomer = saleDTO.getAmountPayedByCustomer();
		this.totPrice = saleDTO.getTotPriceWithoutDiscountAndVAT();
	}

	/**
	 * 
	 * @return total discount
	 */
	public double getTotDiscount() {
		return totDiscount;
	}

	/**
	 * 
	 * @return total vat
	 */
	public double getTotVat() {
		return totVat;
	}

	/**
	 * Sets total vat to the given
	 * @param totVat new VAT amount
	 */
	public void setTotVat(double totVat) {
		this.totVat = totVat;
	}

	/**
	 *
	 * @return ProductList object with all products
	 */
	public ProductList getProductList() {
		return this.productList;
	}


	/**
	 * 
	 * @return store name
	 */
	public String getStoreName() {
		return storeName;
	}

	/**
	 * 
	 * @return store address
	 */
	public String getStoreAddress() {
		return storeAddress;
	}

	/**
	 * 
	 * @return total change
	 */
	public double getTotChange() {
		return totChange;
	}
	
	/**
	 * 
	 * @return date of sale
	 */
	public String getdateOfSale() {
		return this.dateOfSale;
	}

	/**
	 * 
	 * @return amount payed by customer
	 */
	public double getAmountPayedByCustomer() {
		return this.amountPayedByCustomer;
	}

	/**
	 * 
	 * @return total price with discounts and VAT
	 */
	public double getTotPriceWithDiscountsAndVAT() {
		return this.totPrice;
	}
}
