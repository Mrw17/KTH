package model;

/**
 * Class that represents a customer 
 * @author Daniel
 * @version 1.12
 * @since 2019-05-22
 */
public class Customer {
	/**
	 * Customers members number, default 0
	 */
	private int membersNr = 0;
	
	/**
	 * amountSold payed by the customer
	 */
	private double amountPayed = 0;
	
	/** 
	 * CUstombers discount class, default normal
	 */
	private DiscountClass discountClass = DiscountClass.Normal;
	
	/**
	 * Default constructor
	 */
	public Customer() {}
	
	/**
	 * Creates a Customer object with the given data, gets discountClass.Normal
	 * @param newMembersNr Customers members number
	 */
	public Customer(int newMembersNr) {
		this.membersNr = newMembersNr;
	}
	
	/**
	 * Creates a new customers with the given data
	 * @param newMembersNr customers members number
	 * @param newDiscountClass customers discount class
	 */
	public Customer(int newMembersNr, DiscountClass newDiscountClass) {
		this.membersNr = newMembersNr;
		this.discountClass = newDiscountClass;
	}
	
	/**
	 * Gets the customers members number
	 * @return customers members number
	 */
	public int getMembersNr() {
		return membersNr;
	}
	
	/**
	 * Sets customers members number to the given membersNr
	 * @param membersNr new members number of the customer
	 */
	public void setMembersNr(int membersNr) {
		this.membersNr = membersNr;
	}
	
	/**
	 * Gets the customers discount class
	 * @return customers discount class
	 */
	public DiscountClass getDiscountClass() {
		return this.discountClass;
	}
	
	/**
	 * Sets a newDiscountClass to the given DiscountClass
	 * @param newDiscountClass new DiscountClass
	 */
	public void setDiscountClass(DiscountClass newDiscountClass) {
		this.discountClass = newDiscountClass;
	}
	
	/**
	 * Returns discount class as a double value
	 * 25% to 0.25
	 * @return DiscountClass as a double value
	 */
	public double calcDiscountClass() {
		return (double) this.discountClass.getDiscountClass();
	}
	
	/**
	 * @param amountSold payed amountSold
	 */
	public void setAmountPayed(double amount) {
		this.amountPayed += amount;
	}
	
	/**
	 * 
	 * @return amountSold payed
	 */
	public double GetAmountPayed() {
		return this.amountPayed;
	}
}
