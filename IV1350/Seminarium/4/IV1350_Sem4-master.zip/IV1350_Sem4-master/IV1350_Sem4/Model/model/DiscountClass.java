package model;

/**
 * Enum that holds all discount classes
 * @author Daniel
 * @version 1.10
 * @since 2019-05-16
 */
public enum DiscountClass {
	Senior(10),
	Student(10),
	Normal(0),
	VIP(15), 
	Workers(5),
	;
	
	private double discount;
	
	
	/**
	 * Sets the discount
	 * @param discount
	 */
	DiscountClass(int discount){
		this.discount = discount;
	}
	
	/**
	 * Gets the discount(Integer)
	 * @return discount as an integer
	 */
	public double getDiscountClass() {
		return (1 - (discount/100));
	}
}
