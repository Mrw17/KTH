package model;
import java.util.ArrayList;

/**
 * Class that creates a ArrayList with all products
 * @author Daniel
 * @version 1.01
 * @since 2019-05-22
 */
public class ProductList {
	private ArrayList<Product> productList = new ArrayList<Product>();

	/**
	 * 
	 * @return ArrayList with all products
	 */
	public ArrayList<Product> getProductList() {
		return productList;
	}
	
	/**
	 * sets productList(ArrayList<Product>) to the given 
	 * @param productList with all products
	 */
	public void setArrayList(ArrayList<Product> productList) {
		this.productList = productList;
	}
	
	/**
	 * Takes a given product and checks if it is in productlist 
	 * @param newProduct product that shall be added
	 */
	public void addProduct(Product newProduct) {
		if(checkIfProductWithSpecificEanCodeExistsInProductList(newProduct.getEAN()) == false)
			this.productList.add(newProduct);
		else
			this.addProductAmountWithOne(newProduct.getEAN());
	}
	
	/**
	 * Check if a product object with given eancode exists
	 * @param eanCodeToCheck eancode to check after
	 * @return true/false if it found product object
	 */
	private boolean checkIfProductWithSpecificEanCodeExistsInProductList(int eanCodeToCheck) {
		boolean productExistsInShoppingBasket = false;
		for(int i=0; i < this.numberOfProductsInProductList(); i++) {
			if(eanCodeToCheck == this.getProduct(i).getEAN()) {
				productExistsInShoppingBasket = true;
			}
		}
		return productExistsInShoppingBasket;
	}
	
	/**
	 * Adds a specific product object amount with +1
	 * @param eanCode of the product that should be added with +1
	 */
	private void addProductAmountWithOne(int eanCode) {
		this.getProductFromEanCode(eanCode).addOneMoreProduct();
	}
	
	/**
	 * Returns product object from a specific place in productList
	 * @param numberInList place to check for product object
	 * @return product object if it exists on given place, else null
	 */
	public Product getProduct(int numberInList) {
		if(checkIfProductExists(numberInList))
			return this.productList.get(numberInList);
		else
			return null;
	}
	
	/**
	 * Check if a product object exists on a 
	 * specific place
	 * @param numberInList space to check after a product object
	 * @return true/false if it found a product object on a specific place
	 */
	private boolean checkIfProductExists(int numberInList) {
		if(productList.get(numberInList) instanceof Product)
			return true;
		else 
			return false;
	}

	/**
	 * Returns how many products it is in the list
	 * @return size of productList
	 */
	public int numberOfProductsInProductList() {
		return this.productList.size();
	}
	
	/**
	 * Gets a product from the productList based on a products ean.
	 * @param eanCodeSearchingFor eancode to  search for.
	 * @return product object with eanCodeSearchingFor or null if it doesnt' exists in shopping basket.
	 */
	public Product getProductFromEanCode(int eanCodeSearchingFor){
		for(Product product : this.productList) {
			if(product.getEAN() == eanCodeSearchingFor){
				return product;
			}
		}
		return null;
	}
	
	/**
	 * Updates a specific product object with the given product object
	 * @param uppdatedProduct updated product object
	 */
	public void updateProductWithSpecificEanCode(Product uppdatedProduct) {
		int eanCodeToUpdate = uppdatedProduct.getEAN();
		for(Product oldProduct : this.productList) {
			if(oldProduct.getEAN() == eanCodeToUpdate)
				oldProduct = uppdatedProduct;
		}
	}
}
