package model;

/**
 * Contains data about CashRegister
 * @author Daniel
 * @version 1.0
 * @since 2019-05-16
 *
 */
public class CashRegister {
	double balance = 0;
	
	/**
	 * Default constructor
	 */
	public CashRegister() {}
	
	/**
	 * Creates an instance of CashRegister with given startBalance
	 * @param startBalance amount of cashRegister
	 */
	public CashRegister(double startBalance){
		setBalace(startBalance);
	}

	/**
	 * 
	 * @param newBalance newBalance amount
	 */
	public void setBalace(double newBalance) {
		this.balance = newBalance;
	}
	
	/**
	 * 
	 * @return current balance
	 */
	public double getBalance() {
		return this.balance;
	}
}
