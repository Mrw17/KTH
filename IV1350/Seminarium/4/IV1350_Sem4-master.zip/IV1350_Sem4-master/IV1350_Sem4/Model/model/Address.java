package model;

/**
 * Class that represents a address with
 * streetname, housenumber, zipcode and city. 
 * @author Daniel
 * @version 1.0
 * @since 2019-05-22
 */
public class Address {
	private String streetName = "";
	private String houseNumber = "";
	private int zipCode = 0;
	private String city = "";
	
	public Address(String streetName, String houseNumber, int zipCode, String city) {
		this.streetName = streetName;
		this.houseNumber = houseNumber;
		this.zipCode = zipCode;
		this.city = city;
	}
	
	/**
	 * Default constructor
	 */
	public Address() {}

	/**
	 * 
	 * @return street name
	 */
	public String getStreetName() {
		return streetName;
	}
	
	/**
	 * Sets street name to the given
	 * @param streetName new street name
	 */
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	
	/**
	 * 
	 * @return houseNumber
	 */
	public String getHouseNumber() {
		return houseNumber;
	}
	
	/**
	 * Sets houseNumber to the given
	 * @param houseNumber new house number
	 */
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	
	/**
	 * 
	 * @return zip code
	 */
	public int getZipCode() {
		return zipCode;
	}
	
	/**
	 * Sets zip code to the given
	 * @param zipCode new zip code 
	 */
	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}
	
	/**
	 * 
	 * @return city
	 */
	public String getCity() {
		return city;
	}
	
	/**
	 * Sets city to the given
	 * @param city new city 
	 */
	public void setCity(String city) {
		this.city = city;
	}
	
	/**
	 * Overrides toString() with
	 * streetname, housenumber, zipcode, city
	 */
	@Override
	public String toString() {
		return this.streetName + " " + this.houseNumber + " " + this.zipCode + " " + this.city;
	}
}
