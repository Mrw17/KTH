package model;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import integration.InvalidEanCodeException;

public class TestAllDiscountsAndVAT {
	double priceCheese = 20;
	double priceScratch = 25;
	double priceBeer = 15;  
	double priceCigarett = 45;
	Sale newSale = new Sale();
	double expectSum = 0;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		newSale = new Sale();
		expectSum = 0;
		priceCheese = 20;
		priceScratch = 25;
		priceBeer = 15;  
		priceCigarett = 45;
	}

	@AfterEach
	void tearDown() throws Exception {
	}
	
	@Test
	void testAllDiscountsAndVAT() {
		int numberOfCheeses = 4;
		int numberOfBeers = 3;
		int procentDivider = 2;
		double discountFromMemberGroup = 0;
		DiscountClass discountClass = DiscountClass.Student;

		try {
			discountFromMemberGroup = discountClass.getDiscountClass();
			
			for(int i = 0; i < numberOfCheeses; i++) 
				newSale.addProduct(1000);
			
			for(int i = 0; i < numberOfBeers; i++) 
				newSale.addProduct(1002);
			
			newSale.addProduct(1001);
			newSale.addProduct(1003);
			
		}
		catch(CouldNotGetProductFromInventoryException e) {
			assertTrue(e.toString(), false);
		}
	
		expectSum = priceCheese * (numberOfCheeses - (numberOfCheeses%3));
		expectSum += (priceBeer*numberOfBeers)/procentDivider;
		expectSum += priceScratch;
		expectSum += priceCigarett;
		expectSum *= discountFromMemberGroup;	
		newSale.getCustomer().setDiscountClass(discountClass);
		expectSum += newSale.getProductFromEanCode(1000).getToTVat();
		expectSum += newSale.getProductFromEanCode(1001).getToTVat();
		expectSum += newSale.getProductFromEanCode(1002).getToTVat();
		expectSum += newSale.getProductFromEanCode(1003).getToTVat();
		double priceWithDiscountAndVat = newSale.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT();

		assertTrue(priceWithDiscountAndVat == expectSum);
	}
}
