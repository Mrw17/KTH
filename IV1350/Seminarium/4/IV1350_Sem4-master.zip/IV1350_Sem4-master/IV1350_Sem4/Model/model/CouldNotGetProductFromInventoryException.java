package model;

/**
 * Creates an exception if you could not 
 * retrieve a product from the inventory
 * @author Daniel
 * @since 2019-06-02
 * @version 1.0
 */
public class CouldNotGetProductFromInventoryException extends Exception {
	String errMsg = "";
	
	/**
	 * Construct that takes a error message with
	 * which method that failed
	 * @param method
	 */
	public CouldNotGetProductFromInventoryException(String method) {
		errMsg = method;
	}

	/**
	 * @return errMsg with what method that failed
	 */
	@Override
	public String toString() {
		return (errMsg);
	}

}
