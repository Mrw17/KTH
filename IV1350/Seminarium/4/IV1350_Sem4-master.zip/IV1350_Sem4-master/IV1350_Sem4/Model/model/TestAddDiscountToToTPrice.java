package model;

import static org.junit.Assert.assertTrue;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestAddDiscountToToTPrice {
	
	double priceCheese = 20;
	double priceScratch = 25;
	double priceBeer = 15;  
	double priceCigarett = 45;
	Sale newSale = new Sale();
	double expectSum = 0;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		newSale = new Sale();
		expectSum = 0;
		priceCheese = 20;
		priceScratch = 25;
		priceBeer = 15;  
		priceCigarett = 45;
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testBeerHalfPrice() {
		int numberOfBeers = 7;
		int procentDivider = 2;
		int eanCodeBeer = 1002;
		expectSum = ((priceBeer * numberOfBeers)/procentDivider);

		try {
			for(int i = 0; i < numberOfBeers; i++) {
				this.newSale.addProduct(eanCodeBeer);
			}

			CurrentDiscounts checkForDiscount = new CurrentDiscounts();
			ProductList productList = this.newSale.getProductList();
			this.newSale.setShoppingBasket(checkForDiscount.getDiscountAmount(productList));
			double discountOnProduct = this.newSale.getProductFromEanCode(eanCodeBeer).getDiscount();
			assertTrue(discountOnProduct == expectSum);
		}
		catch(CouldNotGetProductFromInventoryException e) {
			assertTrue(e.toString(), false);
		}

	}
	
	
	@Test
	void testCheeseTake3PayFor2() {
	
		int numOfCheeses = 8;
		int eanCode = 1000;
		expectSum = (priceCheese * (numOfCheeses % 3));
		
		try {
			for(int i = 0; i < numOfCheeses; i++) 
				newSale.addProduct(eanCode);
			
			CurrentDiscounts checkForDiscount = new CurrentDiscounts();
			ProductList productList = this.newSale.getProductList();
					
			this.newSale.setShoppingBasket(checkForDiscount.getDiscountAmount(productList));
			this.newSale.setShoppingBasket(productList);
			

		}
		catch(CouldNotGetProductFromInventoryException e) {
			assertTrue(e.toString(), false);
		}	
		assertTrue(this.newSale.getProductFromEanCode(eanCode).getDiscount() == expectSum);
	}
	
	
	@Test
	void testaddDiscountMembersGroup() {
		int numberOfCheeses = 4;
		int numberOfBeers = 3;
		int procentDivider = 2;
		DiscountClass discountClass = DiscountClass.Student;
		double discountFromMemberGroup = discountClass.getDiscountClass();
		double priceWithDiscount = 0;
		
		expectSum = priceCheese * (numberOfCheeses - (numberOfCheeses%3));
		expectSum += (priceBeer*numberOfBeers)/procentDivider;
		expectSum += priceScratch;
		expectSum += priceCigarett;
		expectSum *= discountFromMemberGroup; 		
		
		try {
			for(int i = 0; i < numberOfCheeses; i++) 
				newSale.addProduct(1000);
			
			for(int i = 0; i < numberOfBeers; i++) 
				newSale.addProduct(1002);

			newSale.addProduct(1001);
			newSale.addProduct(1003);
			newSale.getCustomer().setDiscountClass(discountClass);
			
			CurrentDiscounts checkForDiscount = new CurrentDiscounts();
			
			this.newSale.setShoppingBasket(checkForDiscount.getDiscountAmount(newSale.getProductList()));
			priceWithDiscount = this.newSale.getToTPriceWithSaleDiscountAndMemberDiscount();
			
		}
		catch(CouldNotGetProductFromInventoryException e) {
			
		}
		assertTrue(priceWithDiscount == expectSum);
		
	}

}
