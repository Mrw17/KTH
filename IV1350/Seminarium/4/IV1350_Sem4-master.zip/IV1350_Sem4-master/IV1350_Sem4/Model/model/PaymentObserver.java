package model;

/**
 * Listner interface for updating the total when a payment
 * has been made. 
 * @author Daniel
 *
 */
public interface PaymentObserver {
	public void updateToTSale(Sale sale);
}
