package integration;

/**
 * Class that vill catch InvalidEanCodeException
 * @author Daniel
 * @since 2019-06-02
 * @version 1.0
 */
public class InvalidEanCodeException extends Exception {
	private String errMsg = "";
	
	/**
	 * Constructor that takes a errMsg as argument
	 * @param errMsg error message
	 */
	public InvalidEanCodeException(String errMsg) {
		this.errMsg = errMsg;
	}
	
	/**
	 * returns errMsg
	 */
	@Override
	public String toString() {
		return (errMsg);
	}

}
