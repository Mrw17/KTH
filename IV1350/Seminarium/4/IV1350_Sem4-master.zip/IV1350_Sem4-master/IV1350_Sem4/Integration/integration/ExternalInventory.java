package integration;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import model.Product;
import model.ProductList;
import model.VATClass;

/**
 * Simple class that act as an "external inventory" 
 * @author Daniel
 * @version 1.1
 * @since 2019-05-22
 */
public class ExternalInventory {
	
	/**
	 * HashMap that contains all product and how many it is in stock
	 */
	HashMap<Product, Integer> inventoryMap = new HashMap<>();
		
	public ExternalInventory() { 
		this.addTestItems();
	}
	
	/**
	 * Checks if the eancode is eligible or not 
	 * @param productToCheck the eancode to check
	 * @return true/false if its eligible or not
	 */
	public boolean eligibleProductToSale(int eanCodeToCheck) {
		if(checkEligibleEanCode(eanCodeToCheck))
			return true;
		else
			return false;
	}
	
	/**
	 * Checks if an eancode is the range of eligble codes
	 * @param eanToCheck the eancode to check
	 * @return true/false if eanToCheck is in the range or not
	 */
	private boolean checkEligibleEanCode(int eanToCheck)
	{
		boolean check = false;		
		for(Product product : this.inventoryMap.keySet()) {
			if (product.getEAN() == eanToCheck) {
				check = true;
				break;
			}
		}
		return check;
	}
	
	/**
	 * Fills inventory with test data
	 */
	private void addTestItems() {
		
		Product cheese = new Product(1000, "cheese", 20, VATClass.normal);
		Product scratch = new Product(1001, "scratch", 25, VATClass.lottery);
		Product beer = new Product(1002, "beer", 15, VATClass.alcohol);
		Product cigarett = new Product(1003, "Cigarett", 45, VATClass.tobaco);
		
		this.inventoryMap.put(cheese, 15);
		this.inventoryMap.put(scratch, 100);
		this.inventoryMap.put(beer, 30);
		this.inventoryMap.put(cigarett, 50);
		
	}

	/**
	 * 
	 * @return inventory HashMap
	 */
	public HashMap<Product, Integer> getInventory() {
		return this.inventoryMap;
	}
	
	/**
	 * Tries to get a specific product from the inventory
	 * @param eanCode to the specific product
	 * @return product if it founds one, else return null
	 * @throws InvalidEanCodeException if it doesn't find any product with that eancode
	 */
	public Product getProductFromInventory(int eanCode) throws InvalidEanCodeException {
		try {
			if(this.eligibleProductToSale(eanCode) == false)
				throw new InvalidEanCodeException("Eancode not found in database");
			
			for(Product product : this.inventoryMap.keySet()) {
				if (product.getEAN() == eanCode) {
					return product;
				}
			}			
		}
		catch(InvalidEanCodeException e) {
			throw new InvalidEanCodeException(e.toString());
		}
	
		return null;
	}
	
	/**
	 * Updates inventory, e.g removing number of products sold in shoppingBasket
	 * from the inventory
	 * @param productList that contains all the products that has been sold
	 */
	public void uppdateInventoryAfterSale(ProductList productList) {
		Set<Map.Entry<Product, Integer>> entries = this.inventoryMap.entrySet();
		for(int i = 0; i < productList.numberOfProductsInProductList(); i++) {		
			for(Map.Entry<Product, Integer> productInInventory : entries){
				if(inventoryMap.containsKey(productInInventory.getKey())){
					
					String nameOfProductInShoppingBasket = productList.getProduct(i).toString();
					String nameOfProductInInventory = productInInventory.getKey().toString();
					int amountSold = productList.getProduct(i).getAmountSold();

					if(nameOfProductInShoppingBasket.equals(nameOfProductInInventory)) 
						this.inventoryMap.replace(productInInventory.getKey(), (productInInventory.getValue() - amountSold));
				}
			}
		}
	}			
}
