package integration;
import model.ProductList;
import model.Sale;

/**
 * DTO class that contains all data that saleExternalAccounting needs
 * @author Daniel
 * @version 1.0
 * @since 2019-05-22
 *
 */
public class SaleExternalInventoryDTO {
	Sale newSale = new Sale();
	
	/**
	 * Constructor that takes a sale
	 * @param newSale new Sale object
	 */
	public SaleExternalInventoryDTO(Sale newSale) {
		this.newSale = newSale;
	}
	
	/**
	 * Sends all data to ExternalInventory
	 * @return getProductList with all products
	 */
	public ProductList sendToExternalInventory() {
		return this.newSale.getProductList();
	}

}
