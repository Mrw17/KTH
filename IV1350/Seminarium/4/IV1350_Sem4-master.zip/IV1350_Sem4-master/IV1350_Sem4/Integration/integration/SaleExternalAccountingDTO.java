package integration;
import model.Sale;

/**
 * Class that send all data to an external accounting system
 * @author Daniel
 * @version 1.0
 * @since 2019-05-16
 */
public class SaleExternalAccountingDTO {
	private Sale sale = new Sale();
	
	/**
	 * Default Constructor
	 */
	public SaleExternalAccountingDTO() {}
	
	/**
	 * Constructor that takes a new sale object
	 * @param newSale
	 */
	public SaleExternalAccountingDTO(Sale newSale) {
		this.sale = newSale;
	}
	
	
	/**
	 * @return all data that external accounting requires 
	 */
	public Sale sendToExternalAccounting() {
		return this.sale;
	}
	
}
