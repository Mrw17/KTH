package integration;

import java.util.ArrayList;

/**
 * Class that represents External Accounting
 * Only saves new sales in a arrayList
 * @author Daniel
 * @version 1.0
 * @since 2019-05-16
 *
 */
public class ExternalAccounting {
	
	private ArrayList<SaleExternalAccountingDTO> allSales = new ArrayList<SaleExternalAccountingDTO>();

	/**
	 * Default Constructor
	 */
	public void newSale() {}    
	
	
	/**
	 * Saves a new sale in arrayList
	 * @param newSale sale to be saved
	 */
	public void saveNewSale(SaleExternalAccountingDTO newSale) {
		this.allSales.add(newSale);
	}
}


