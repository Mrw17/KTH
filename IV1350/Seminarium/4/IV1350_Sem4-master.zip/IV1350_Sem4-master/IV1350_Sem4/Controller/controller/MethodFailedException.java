package controller;

public class MethodFailedException extends Exception {
	String errMsg = "";
	public MethodFailedException(String errMsg) {
		this.errMsg = errMsg;
	}

	
	@Override
	public String toString() {
		return ("Method Failed to execute: " + errMsg);
	}
}
