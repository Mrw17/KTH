package controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import integration.*;
import model.*;

/**
 * 
 * @author Daniel
 * @since 2019-06-02
 * @version 1.3
 */
public class Controller {
	
	private Store store = new Store();
	private Sale newSale = new Sale();
	private RecipePrinter recipePrinter = new RecipePrinter();
	private ExternalInventory extInventory = new ExternalInventory();
	private ExternalAccounting extAccountint = new ExternalAccounting();
	private CashRegister cashRegister = new CashRegister(1000);
    private List<PaymentObserver> paymentObservers = new ArrayList(); 

    
	/**
	 * Default constructor
	 */
	public Controller() {}
	
	/**
	 * Creates an instance of Controller with given printerReceipt
	 * @param printerReceipt new recipePrinter
	 */
	public Controller(RecipePrinter printerReceipt) {
		this.recipePrinter = printerReceipt;
	}
	
	/**
	 * Associate sale with a given customer
	 * @param newCustomer new customer
	 */
	public void setCustomer(Customer newCustomer) {
		newSale.setCustomer(newCustomer);
	}
	
	/**
	 * 
	 * @return customer that is associate with the sale
	 */
	public Customer getCustomer() {
		return newSale.getCustomer(); 
	}
	
	/**
	 * Adds a product to the sale
	 * @param eanCode of the new product
	 * @throws MethodFailedException 
	 */
	public void addProduct(int eanCode) throws MethodFailedException {
		try {
			newSale.addProduct(eanCode);
		}
		catch(CouldNotGetProductFromInventoryException e) {
			throw new MethodFailedException("controller.addProduct: " + e.toString());
		}
		
	}
	
	/**
	 * "Starts a new sale" with a new 
	 * instance of Sale object
	 */
	public void startNewSale() {
		newSale = new Sale();
	}
	
	/**
	 * 
	 * @return HashMap with external inventory
 	 */
	public HashMap<Product, Integer> getInventory() {
		return extInventory.getInventory();
	}
	
	/**
	 * 
	 * @return total price with sale discount + members discount and VAT
	 */
	public double getToTPriceWithSaleDiscountAndMembersDiscountAndVAT() {
		return newSale.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT();
	}
	
	/**
	 * Sets customer payed amount to the given
	 * @param amountPayed by the customers
	 */
	public void customerPays(double amountPayed) {
		this.newSale.getCustomer().setAmountPayed(amountPayed);
	}
	
	/**
	 * 
	 * @return how much change customer should receive
	 */
	public String getChange() {		
		return this.newSale.getChange();
	}
	
	/**
	 * Change status on cashier to the given
	 * @param status cashier new status on the sale
	 */
	public void setCashierApprovedSale(boolean status) {
		this.newSale.setCashierApproved(status);
		this.newSale.addPaymentObservers(paymentObservers);
;		notiftyObservers();
	}
	
	/**
	 * 
	 * @param status
	 */
	public void setCustomerApproved(boolean status) {
		this.newSale.setCustomerApproved(status);
	}
	
	/**
	 * Sets cash register balance to the given
	 * @param newBalance new balance of cash register
	 */
	public void setCashRegisterBalance(double newBalance) {
		cashRegister.setBalace(this.cashRegister.getBalance() + this.newSale.getCustomer().GetAmountPayed());
	}
	
	/**
	 * 
	 * @return cash register balance
	 */
	public double getCashRegisterBalance() {
		return this.cashRegister.getBalance();
	}	
	
	/**
	 * 
	 * @return current sale 
	 */
	public Sale getSale() {
		return this.newSale;
	}
	
	/**
	 * Updates store name to the given
	 * @param newName new name of the store
	 */
	public void setStoreName(String newName) {
		this.store.setName(newName);
	}
	
	/**
	 * 
	 * @return store object
	 */
	public Store getStore() {
		return this.store;
	}
	
	/**
	 * Updates stores street name to the given
	 * @param newStreetname name of the new street
	 */
	public void setStoreAddressStreetname(String newStreetname) {
		this.store.setAddressStreetname(newStreetname);
	}

	/**
	 * Updates store house number
	 * @param newHouseNumber new house number
	 */
	public void setStoreAddressHouseNumber(String newHouseNumber) {
		this.store.setAddressHouseNumber(newHouseNumber);
	}
	
	/**
	 * Creates instance of SaleExternalAccountingDTO and 
	 * sends it to ExternalAccoutning
	 */
	public void sendToExternalAccounting() {
		SaleExternalAccountingDTO saleExternalAccountingDTO = new SaleExternalAccountingDTO(this.newSale);
		this.extAccountint.saveNewSale(saleExternalAccountingDTO);
	}
	
	/**
	 * Creates saleToExternalInventoryDTO and
	 * sends it to ExternalInventory
	 */
	public void sendToExternalInventory() {
		SaleExternalInventoryDTO saleToExternalInventoryDTO= new SaleExternalInventoryDTO(this.newSale);		
		this.extInventory.uppdateInventoryAfterSale(saleToExternalInventoryDTO.sendToExternalInventory());
	}
	
	/**
	 * Creates instance of Recipe with SaleDTO object
	 * and sends it to RecipePrinter
	 */
	public void createRecipe() {
		Recipe newRecipe = new Recipe(new SaleDTO(this.store, this.newSale));
		RecipePrinterDTO newRecipePrinterDTO = new RecipePrinterDTO(newRecipe);
		this.recipePrinter = new RecipePrinter(newRecipePrinterDTO);
	}
	
	/**
	 * 
	 * @return total price without any discount
	 */
	public double getToTPriceWithoutDiscountOrVAT() {
		return this.newSale.getToTPriceWithoutDiscount();
	}
	
	/**
	 * 
	 * @return total price with
	 * sale discounts
	 */
	public double getToTPriceWithDiscounts() {
		
		return this.newSale.getToTPriceWithSaleDiscount();
	}	
	
	/**
	 * 
	 * @return total price with
	 * sale discount
	 * members discount
	 * VAT 
	 */
	public double getToTPriceWithSaleDiscountAndMemberDiscountAndVAT() {
		return this.newSale.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT();
	}
	
	/**
	 * Updates stores zip code to the given
	 * @param newZipCode new zip code
	 */
	public void setStoreAddressZipCode(int newZipCode) {
		this.store.setAddressZipCode(newZipCode);
		
	}
	
	/**
	 * Updates stores city with the given
	 * @param newCity new city 
	 */
	public void setStoreAddressCity(String newCity) {
		this.store.setAddressCity(newCity);
		
	}
	
	/**
	 * 
	 * @return String with whole recipe
	 */
	public String getRecipeOutput() {
		return recipePrinter.printRecipe();		 
	}
	
	/**
	 * Adds observer to observerlist
	 * @param d
	 */
	public void addPaymentObserver(PaymentObserver d) {
		paymentObservers.add(d);

	}
	
	/**
	 * Notify all the observers
	 */
	public void notiftyObservers() {
		for(int i = 0; i < paymentObservers.size(); i++) {
			this.paymentObservers.get(i).updateToTSale(this.getSale());
		}
	}
}
