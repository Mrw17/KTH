package view;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

/**
 * Class that will handle 
 * error message that will be shown
 * for the end user
 * @author Daniel
 * @since 2019-06-02
 * @version 1.0
 *
 */
public class ErrorMessageHandler {

	/**
	 * Builds a error message that will contain:
	 * date when it happend
	 * ERROR
	 * error message
	 * and alos print it to the console
	 * @param msg
	 */
	void showErrorMsg(String msg) {
		 StringBuilder errorMsgBuilder = new StringBuilder();
		 errorMsgBuilder.append(createTime());
		 errorMsgBuilder.append(", ERROR: ");
		 errorMsgBuilder.append(msg);
		 System.out.println(errorMsgBuilder);
	
	}
	
	/**
	 * 
	 * @return current date
	 */
	private String createTime() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
		return now.format(formatter);
	}
	
}
