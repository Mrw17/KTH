package view;

/**
 * Simple View class for Revenue 
 * @author Daniel
 * @since 2019-08-27
 * @version 1.1
 */

import model.PaymentObserver;
import model.Sale;

public class TotalRevenueView implements PaymentObserver{
	double sum = 0;

	/*
	 * Skriver ut totala summan
	 */
    private void printCurrentRevenue(){
        System.out.println("*** TOTAL REVENUE ***");
        System.out.println("   Amount: " + sum);
        System.out.println("*********************\n");
    }

    /*
     * Spar totala summan och skriver ut den
     * @see model.PaymentObserver#updateToTSale(model.Sale)
     */
	@Override
	public void updateToTSale(Sale sale) {
		sum += sale.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT();
		printCurrentRevenue();
	}	
}
