package view;
import java.io.IOException;

import controller.*;
import integration.InvalidEanCodeException;
import model.CouldNotGetProductFromInventoryException;

/**
 * Placeholder for view
 * @author Daniel
 * @version 1.1
 * @since 2019-06-02
 *
 */
public class View {
	
	Controller controller = new Controller();
	
	/**
	 * Default constructor
	 */
	public View() {}
	
	/**
	 * Constructor that takes a controller object
	 * @param controller
	 */
	public View(Controller controller) {
		this.controller = controller;
	}
	
	/**
	 * Runs a simple demonstration of the program
	 * with hard coded inputs
	 * @throws IOException 
	 */
	public void showDemostration() throws IOException {
		try {
			ViewDemo viewDemo = new ViewDemo(this.controller);
			viewDemo.showDemostration();
		} catch (InvalidEanCodeException | MethodFailedException | CouldNotGetProductFromInventoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
}
