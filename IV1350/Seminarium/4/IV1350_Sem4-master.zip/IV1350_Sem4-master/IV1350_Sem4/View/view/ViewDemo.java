package view;
import controller.*;
import integration.InvalidEanCodeException;
import model.CouldNotGetProductFromInventoryException;
import util.LogHandler;
import java.io.IOException;
 

/**
 * Simple demonstration of the program
 * @author Daniel
 * @version 1.2
 * @since 2019-06-02
 *
 */
public class ViewDemo {
	
	private Controller controller = new Controller();
	private ErrorMessageHandler errMsgHandlr = new ErrorMessageHandler();
	private LogHandler logger;

	/**
	 * Constructor that takes a controller as argument
	 * thorws IOException if anything fails with logger output to .txt file
	 * @param controller new controller
	 * @throws IOException
	 */
	public ViewDemo(Controller controller) throws IOException {
		this.controller = controller;
		this.logger = new LogHandler();
        controller.addPaymentObserver(new TotalRevenueView());
	} 
	

	/**
	 * Runs a simple demonstration of the program
	 * @throws InvalidEanCodeException 
	 * @throws MethodFailedException 
	 * @throws CouldNotGetProductFromInventoryException 
	 */
	public void showDemostration() throws InvalidEanCodeException, MethodFailedException, CouldNotGetProductFromInventoryException{
		
				
		this.controller.setStoreAddressStreetname("Coolstreet");
		this.controller.setStoreAddressHouseNumber("123");
		this.controller.setStoreAddressZipCode(12345);
		this.controller.setStoreAddressCity("cooltown");
		
		this.controller.setStoreName("Very Cool shop");
		demostrationPrintStore();
		
		System.out.println("Current inventory (product, quantity)");
		System.out.println(controller.getInventory().toString());
			
		demostrationShowCashRegisterBalance();
		
		System.out.println("\n\n\n***Cashier starts a new sale***");
		controller.startNewSale();	
			 
			
		System.out.println("***Cashier scanning product(cheese)***");
		demostrationScanProduct(1000);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
		System.out.println("***Cashier scanning product(cheese)***");
		demostrationScanProduct(1000);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
		System.out.println("***Cashier scanning product(cheese)***");
		demostrationScanProduct(1000);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
		System.out.println("***Cashier scanning product(cheese)***");
		demostrationScanProduct(1000);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
			
		System.out.println("***Cashier scanning product(scratch)***");
		demostrationScanProduct(1001);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
			
			
		System.out.println("***Cashier scanning product(beer)***");
		demostrationScanProduct(1002);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
		System.out.println("***Cashier scanning product(beer)***");
		demostrationScanProduct(1002);
		demostrationShowToTPriceWithoutDiscountOrVAT();
					
		System.out.println("***Cashier scanning product(cigarette)***");
		controller.addProduct(1003);
		demostrationShowToTPriceWithoutDiscountOrVAT();
		
		System.out.println("***Cashier scanning product with eancode that doesnt exists in inventory***");
		demostrationScanProduct(1005);		
		demostrationShowToTPriceWithoutDiscountOrVAT();
		System.out.println("***No more products to scan***\n\n");	
		
		
		System.out.print("Show total price with discount: ");
		System.out.println(controller.getToTPriceWithDiscounts());
		
		System.out.print("Show total price with discount + VAT: ");
		System.out.println(controller.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT());
			
		System.out.println("***Customer  approves***");
		controller.setCustomerApproved(true);
				
		System.out.println("***Cashier approves***");
		controller.setCashierApprovedSale(true);
			
		demostrationCustomerPays(100);
		demostrationPrintChange();
		
	
		demostrationCustomerPays(100);
		demostrationPrintChange();		
			
		//controller.paymentDone();
		
		
		controller.createRecipe();
		System.out.println(controller.getRecipeOutput());
				
		controller.sendToExternalAccounting();
		controller.sendToExternalInventory();

		System.out.println("\n\nCurrent inventory (product, quantity)");
		System.out.println(controller.getInventory().toString());
		
		// Sale nr 2
		System.out.println("*****BUY NUMBER 2******");
		controller.startNewSale();	

		System.out.println("***Cashier scanning product(cheese)***");
		demostrationScanProduct(1000);
		demostrationShowToTPriceWithoutDiscountOrVAT();
			
		System.out.println("***Cashier scanning product(cheese)***");
		demostrationScanProduct(1000);
		demostrationShowToTPriceWithoutDiscountOrVAT();
		
		System.out.print("Show total price with discount: ");
		System.out.println(controller.getToTPriceWithDiscounts());
		
		System.out.print("Show total price with discount + VAT: ");
		System.out.println(controller.getToTPriceWithSaleDiscountAndMemberDiscountAndVAT());
			
		System.out.println("***Customer  approves***");
		controller.setCustomerApproved(true);
				
		System.out.println("***Cashier approves***");
		controller.setCashierApprovedSale(true);
			
		demostrationCustomerPays(100);
		demostrationPrintChange();
	
		controller.createRecipe();
		System.out.println(controller.getRecipeOutput());
				
		controller.sendToExternalAccounting();
		controller.sendToExternalInventory();

	
	}
	
	/**
	 * Prints Change
	 */
	private void demostrationPrintChange() {
		System.out.println(controller.getChange());
	}
	
	/**
	 * Prints out how much customer pays
	 * @param amount
	 */
	private void demostrationCustomerPays(double amount) {
		System.out.println("Customer pays " + amount);
		controller.customerPays(amount);
	}
	
	/**
	 * Prints out cashregister balance
	 */
	private void demostrationShowCashRegisterBalance() {
		System.out.print("Current cashregister balance: ");
		System.out.println(controller.getCashRegisterBalance());
	}
	
	/**
	 * Tries to add a product to the sale 
	 * catch MethodFailedException if it failed
	 * and forwards errorMsg and exception to
	 * this.handleException
	 * @param ean eancode of the product
	 */
	private void demostrationScanProduct(int ean){
		try {
			controller.addProduct(ean);
		} catch (MethodFailedException exception) {
			handleException("Product with eancode: " + ean + " could not be added", exception);
		}
	}
	
	/**
	 * Prints out total price
	 */
	private void demostrationShowToTPriceWithoutDiscountOrVAT() {
		System.out.println("\nShow total price " + controller.getToTPriceWithoutDiscountOrVAT());
	}
	
	/**
	 * Prints out store information
	 */
	private void demostrationPrintStore() {
		System.out.println(this.controller.getStore().getName() + " " + this.controller.getStore().getAddress() + "\n\n");
	}	
	
	/**
	 * Makes errorhandling easier. Shows error message to user
	 * and loggs a more detail error message to a .txt file for developer
	 * @param uiMsg message to been show to enduser
	 * @param exc exception to be printed to .txt file
	 */
	private void handleException(String uiMsg, Exception exc) {
		this.errMsgHandlr.showErrorMsg(uiMsg);
		this.logger.logException(exc);
	}
}
