//Task 3

import java.net.*;
import java.io.*;
import tcpclient.TCPClient;

public class HTTPAsk {
	public static void main(String[] args) throws IOException {
	int srvPort;  
  	String host = null;
  	String port = null;
  	String strInput = null;
	String strFromClient = null;
  	String answer = null;

  	
  	//Choice right port, def 8888 if no arg is sent
  	try {
        	srvPort = Integer.parseInt(args[0]);
    	}
	catch (Exception e) {
        	srvPort = 8888;
    	}
  	
  	//Creating socket on port (from argument)
  	ServerSocket welcomeSocket = new ServerSocket(srvPort);
  	
  	//Catches errors
	try {
		while(true) {
  				System.out.println("*****Start*****");
  				
				//reset variables
				host = null;
				port = null;
				strInput = null;
				
  				//Wait on client contact
  				Socket connectionSocket = welcomeSocket.accept();
  				
  				//welcomeSocket.setSoTimeout(3000);
  				//Creates input stream, from socket
  				BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
  				
  				//Creates output stream, from socket
  				DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());	
				  				  				 
  				StringBuilder sB = new StringBuilder();  				
  				
  				 //while((strFromClient = inFromClient.readLine()) != null && strFromClient.length() !=0 ) {
  					//sB.append(strFromClient + "\r\n");
  				
  				//}
  			
  				//Read input from client 
  				strFromClient = inFromClient.readLine();
  				//System.out.println(strFromClient);
  				//Splits input 
				
  				String[] uri = strFromClient.split("[ =&?/]");
				System.out.println(uri[2]);
				
  				//Checks after ask
  				if(uri[2].equals("ask")) {
					System.out.println("ask");
					
  					//Loops through uri 
  					for(int i = 0; i < uri.length; i++) {
  						
  	  					//Checks and save hostname
  						if(uri[i].equals("hostname"))
  							host = uri[i+1];
  						
  						//Checks and save port
  						else if(uri[i].equals("port")) 
  							port = uri[i+1];
  						
  						//Checks and save string
  						else if(uri[i].equals("string")) 
  							strInput = uri[i+1];
  				
  					}
  			  	
  				//Askserver
  			  	try {  				
					System.out.println("Calling TCPClient.askServer with host: " + host + " port: " + port + " input: " + strInput);
  			  		answer = TCPClient.askServer(host, Integer.parseInt(port), strInput); 			  			
					String header = "HTTP/1.1 200 OK\r\n\r\n";
  			  		outToClient.writeBytes(header + answer + "\r\n");
					System.out.println("200");
  			  	}
				
				//404
  			  	catch(Exception e) {
  			  		System.out.println("404");
  			  		outToClient.writeBytes("HTTP/1.1 404 Not Found\r\n");
  			  		}
  				}
  					
				// 400
  				else {
					System.out.println("400");
  					outToClient.writeBytes("HTTP/1.1 400 Bad Request\r\n");
  				}

  				//Closing sockets
  				connectionSocket.close();
  				inFromClient.close();
  				outToClient.close();
  				
  				//System.out.println(outToClient.toString());
  				System.out.println("*****End*****");
  			
				}
			}
  		//Shows error msg
  		catch(Exception e) {
  			System.out.println("error");
  		}
  	}    	
  }