//Task 2 
//package task2;

import java.net.*;
import java.io.*;

public class HTTPEcho {
    @SuppressWarnings("resource")
	public static void main( String[] args) throws IOException {
        
    	int port = Integer.parseInt(args[0]);
    	//int port = 8888;
    	
    	
    	//Creating socket on port (from argument)
    	ServerSocket welcomeSocket = new ServerSocket(port);
    	
    	
    	while(true) {
    		try {
    				System.out.println("Start");
    				
    				//Wait on client contact
    				Socket connectionSocket = welcomeSocket.accept();
    				
    				welcomeSocket.setSoTimeout(3000);
    				//Creates input stream, from socket
    				BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
    				
    				//Creates output stream, from socket
    				DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());	
    				
    				//Stringbuilder for output
    				StringBuilder sB = new StringBuilder();
    				sB.append("HTTP/1.1 200 OK\r\n\r\n");
    				
    				String strFromClient = "";
    
    				//Reads from-client-socket and adds in to send-to-client-socket
    				//Ignoring empty strings
    				while( (strFromClient = inFromClient.readLine()) != null && strFromClient.length() !=0 ) {
    					sB.append(strFromClient + "\r\n");
    				}
    				
    				//Output
    				outToClient.writeBytes(sB.toString());
    				
    				//Closing sockets
    				connectionSocket.close();
    				inFromClient.close();
    				outToClient.close();
    				
    				System.out.println("End");
    			
    		}
    		//Shows error msg
    		catch(Exception e) {
    			//System.out.println(e.toString());
    		}
    	}    	
    }
}

