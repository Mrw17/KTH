//Task 1 

package tcpclient;
import java.net.*;
import java.io.*;

public class TCPClient {	
	
	//Global varibels
	static int TIMEOUT = 4000;
	static int MAX_ROWS = 32;
	
    public static String askServer(String hostname, int port, String ToServer) throws  IOException {
    	
    	//Runs the other askServer if its only 2 arg
    	if(ToServer == null)
    		return askServer(hostname, port);
    	else {
    		
        	//Client socket, connects to the server
        	Socket clientSocket = new Socket(hostname, port);
        	
	    	//Socket timer
	    	clientSocket.setSoTimeout(TIMEOUT);
	    	
	    	//output stream
	    	DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
	    	
	    	//input stream		
	  	   	BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
	    
	    	//Sends data to socket (server)
	    	outToServer.writeBytes(ToServer + "\n");   	   	
	
			//Variabels for read socket
	    	//Stringbuilder that builds a string from recivied data
	  	 	StringBuilder sB = new StringBuilder();
	    	String s ="";
	    	String fromServer = "";
	    	int countRows = 0;
	    	
	    	// Try/Catch that reads from socket(data from server)
	    	try{   		
	    			//Loop  that reads socket (dont mind blank spaces etc) 
			  		while((s = inFromServer.readLine()) != "\n" && s != null){
		    			sB.append(s+'\n');
		    			
						//Counter that counts number of rows that has been read
		    			countRows++;
		    			//Read at most MAX_ROWS rows from socket(else chargen reads for ever)
		    			if(countRows > MAX_ROWS)
		    				break;
		    			}
			  	}	
		  	   			  	   
	    		//Catch upp error, can print error message. 
		  	   	catch(IOException e){
		  	   		//System.out.println("Timeout " + e.toString() );
		  	   	}

	    		//Close the socket
	    		finally {
	    			clientSocket.close();
	    		}
   		
	  	//Return 
	  	fromServer = sB.toString();
	  		
    	//Returns data from server
		return fromServer;
    	}
    }

    //Without data to server
    public static String askServer(String hostname, int port) throws  IOException {
    	
    	//Client socket, connects to server
    	Socket clientSocket = new Socket(hostname, port);
    	
    	//Socket timer
    	clientSocket.setSoTimeout(TIMEOUT);
    	
    	//input stream
    	BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
    		
    	//Stringbuilder that builds a string from data that it reads from the socket 
  	 	StringBuilder sB = new StringBuilder();
    	String s = "";
    	String fromServer = "";
    	int countRows = 0;
    	
    	
    	// Try/Catch that reads data from 5he socket. 
    	try{   		
    			//Loopar through the socket and reads the data, dont mind blank spacec
		  		while( (s = inFromServer.readLine()) != "\n" && s != null){
	    			sB.append(s+'\n');
	    			countRows++;
	    			
	    			//Only read MAX_ROWS rows(Mostley for chargen)
	    			if(countRows > MAX_ROWS)
	    				break;
	    			}
		  		
		  		
		  	}	
	  	   			  	   	
    		//Catch error msg, can print it
	  	   	catch(IOException e){
	  	   		//System.out.println("Timeout " + e.toString());
	  	   	}

    		//Close socket
    		finally {
    			clientSocket.close();
    		}    	
    	//Returns
  		fromServer = sB.toString();
  		
    	return fromServer;
    }
}

