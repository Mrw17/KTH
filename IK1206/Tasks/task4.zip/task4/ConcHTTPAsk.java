//Task 4
//package task4;

import java.net.*;
import java.io.*;

public class ConcHTTPAsk {

	public static void main(String[] args) throws IOException {

		int srvPort;  
	  	
	  	//Choice right port, def 8888 if no arg is sent
	  	try {
	        	srvPort = Integer.parseInt(args[0]);
	    	}
		catch (Exception e) {
				System.out.println("Using default port 8888");
	        	srvPort = 8888;
	    	}
	  	
	  	//Creating socket on port (from argument)
	  	ServerSocket welcomeSocket = new ServerSocket(srvPort);
	  	
	  	//Catches errors
		try {
			while(true) {
			//Wait on client contact
			Socket connectionSocket = welcomeSocket.accept();
			new Thread(new MyRunnable(connectionSocket)).start();
					
			//welcomeSocket.setSoTimeout(3000);
	  					  			
			}
		}
	  		//Shows error msg
	  		catch(IOException e) {
	  			System.out.println("error");
	  		}
	  	}    	
	  }