//Task 4 
//package task4;
import java.net.Socket;
import java.io.*;

import tcpclient.TCPClient;

public class MyRunnable implements Runnable {
	
	Socket connectionSocket = null;
	
	//Constructor that takes a socketin 
	public MyRunnable(Socket sockIn){
		connectionSocket = sockIn;
	}
	
	/*
	 * Starts a new thread
	 * Connects to server through TCPClient
	 */
	public void run() {	
	
		try {
			String host = null;
			String port = null;
			String strInput = null;
			String strFromClient = null;
			String answer = null;

			
			System.out.println("*****Start new thread*****");
				
			//reset variables
			host = null;
			port = null;
			strInput = null;
			

			//Creates input stream, from socket
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
				
			//Creates output stream, from socket
			DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());	
			  				  				 
			StringBuilder sB = new StringBuilder();  				
			
			//Read input from client 
			strFromClient = inFromClient.readLine();
			
			//Splits input 			
			String[] uri = strFromClient.split("[ =&?/]");
			System.out.println(uri[2]);
			
			//Checks after ask
			if(uri[2].equals("ask")) {
			System.out.println("ask");
				
				//Loops through uri 
				for(int i = 0; i < uri.length; i++) {
						
					//Checks and save hostname
					if(uri[i].equals("hostname"))
						host = uri[i+1];
						
					//Checks and save port
					else if(uri[i].equals("port")) 
						port = uri[i+1];
					
					//Checks and save string
					else if(uri[i].equals("string")) 
						strInput = uri[i+1];
			
				}
			  	
			//Askserver
			try{  				
				System.out.println("Calling TCPClient.askServer with host: " + host + " port: " + port + " input: " + strInput);
				answer = TCPClient.askServer(host, Integer.parseInt(port), strInput); 			  			
				String header = "HTTP/1.1 200 OK\r\n\r\n";
				outToClient.writeBytes(header + answer + "\r\n");
				System.out.println("200");
				
				//For testing
				//System.out.println("Thread sleeping for 5sec");
				//Thread.sleep(5000);
				//System.out.println("Thread awake agains");
			}
			
			//404
			catch(Exception e) {
				System.out.println("404");
			  	outToClient.writeBytes("HTTP/1.1 404 Not Found\r\n");
			  	}
			}
					
				// 400
				else {
					System.out.println("400");
					outToClient.writeBytes("HTTP/1.1 400 Bad Request\r\n");
				}

				//Closing sockets
				connectionSocket.close();
				inFromClient.close();
				outToClient.close();
				
				//System.out.println(outToClient.toString());
				System.out.println("*****End thread*****");
		}
		catch(IOException e){
			System.out.print("Error " + e.toString());
		}	
	}
}